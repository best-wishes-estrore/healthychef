﻿using HealthyChef.DAL;
using HealthyChef.DAL.Classes;
using System.Collections.Generic;
using System.Linq;

namespace HealthyChef.WebModules.Reports.Admin
{
    public class QueryAll
    {
        public QueryAll(healthychefEntities context, QueryDataObject data)
        {
            Context = context;
            Data = data;
        }

        public QueryDataObject Data
        {
            get;
            set;
        }

        public healthychefEntities Context
        {
            get;
            set;
        }

        public virtual List<ActiveCustomerDto> Process(IQueryable<DAL.hccCart> query)
        {
            return query.GroupJoin(Context.hccUserProfiles,
                      cart => cart.AspNetUserID,
                      profile => profile.MembershipID,
                      (c, p) => new { cart = c, profile = p.DefaultIfEmpty() })
                  .SelectMany(g => g.profile.Select(profile => new { cart = g.cart, profile }).Where(x => x.profile.IsActive))
                  .Join(Context.aspnet_Membership,
                      cart => cart.cart.AspNetUserID,
                      member => member.UserId,
                      (c, m) => new { cart = c.cart, profile = c.profile, member = m })
                  .GroupBy(u => new { u.member.UserId })
                  .Select(u => new
                  {
                      FirstPurchaseDate = Context.hccCarts.Where(c => u.Select(y => y.cart.AspNetUserID).Contains(c.AspNetUserID)).Min(c => c.PurchaseDate),
                      LastPurchase = u.FirstOrDefault(x => x.cart.PurchaseDate == u.Max(c => c.cart.PurchaseDate))
                  })
                  .Where(u =>
                      u.LastPurchase.cart.PurchaseDate >= Data.StartTime
                      && u.LastPurchase.cart.PurchaseDate <= Data.EndTime
                      && u.LastPurchase.member.IsApproved)
                  .Select(u => new ActiveCustomerDto
                  {
                      Email = u.LastPurchase.member.Email,
                      CustomerName = u.LastPurchase.profile.LastName + ", " + u.LastPurchase.profile.FirstName,
                      Address = u.LastPurchase.profile.hccAddressShipping.Address1 + (!string.IsNullOrEmpty(u.LastPurchase.profile.hccAddressShipping.Address2) ? ", " + u.LastPurchase.profile.hccAddressShipping.Address2 : ""),
                      ZipCode = u.LastPurchase.profile.hccAddressShipping.PostalCode,
                      PhoneNumber = u.LastPurchase.profile.hccAddressShipping.Phone,
                      FirstPurchaseDate = u.FirstPurchaseDate,
                      LastPurchaseDate = u.LastPurchase.cart.PurchaseDate,
                      LastPurchaseAmount = u.LastPurchase.cart.TotalAmount,
                      LastPurchaseId = u.LastPurchase.cart.PurchaseNumber,
                      MktgOptIn = (u.LastPurchase.profile.CanyonRanchCustomer ?? false) ? "Y" : "N"
                  })
                  .OrderBy(c => c.CustomerName)
                  .ToList();
        }
    }
}