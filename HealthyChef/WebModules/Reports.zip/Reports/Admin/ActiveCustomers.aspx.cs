﻿using HealthyChef.DAL;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Objects;
using HealthyChef.DAL.Classes;
using HealthyChef.Common;

namespace HealthyChef.WebModules.Reports.Admin
{
    public partial class ActiveCustomers : System.Web.UI.Page
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            rvwCustomers.ReportRefresh += RefreshReport;
            rvwCustomers.ReportError += ShowReportErrors;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hccProductionCalendar cal = hccProductionCalendar.GetNext4Calendars().FirstOrDefault();

                txtStartDate.Text = cal == null ? DateTime.Now.ToShortDateString() : cal.DeliveryDate.ToShortDateString();
                txtEndDate.Text = cal == null ? DateTime.Now.ToShortDateString() : cal.DeliveryDate.ToShortDateString();

                BindProductTypes();
            }
        }

        private void BindProductTypes()
        {
            if (ddlProductTypes.Items.Count < 1)
            {
                using (var context = new healthychefEntities())
                {
                   Dictionary<string, int> dataSource = new Dictionary<string, int>();

                   var programs = context.hccPrograms.ToList();
                   foreach (var program in programs)
                   {
                       dataSource.Add(program.Name, program.ProgramID);
                   }

                   dataSource.Add("A La Carte", -2);
                   dataSource.Add("Gift Certificate", -3);

                   ddlProductTypes.DataSource = dataSource;
                   ddlProductTypes.DataTextField = "Key";
                   ddlProductTypes.DataValueField = "Value";

                   ddlProductTypes.DataBind();

                   ddlProductTypes.Items.Insert(0, new ListItem("<< All Product Types >>", "-1"));
                }
            }
        }

        private void BindReport()
        {
            Page.Validate("CustomerGroup");

            if (Page.IsValid)
            {
                DateTime start;

                bool startDateIsValid = DateTime.TryParse(txtStartDate.Text.Trim(), out start);

                DateTime end;

                bool endDateIsValid = DateTime.TryParse(txtEndDate.Text.Trim(), out end);

                int programId = int.Parse(ddlProductTypes.SelectedValue);

                rvwCustomers.LocalReport.ReportPath = Server.MapPath("~/WebModules/Reports/ActiveCustomers.rdlc");
                var ds = new ReportDataSource("ActiveCustomers", GetQueryResults(start, end, programId));

                rvwCustomers.LocalReport.DataSources.Clear();

                rvwCustomers.LocalReport.DataSources.Add(ds);

                rvwCustomers.LocalReport.Refresh();
            }
        }

        protected void RefreshReport(object sender, EventArgs e)
        {
            BindReport();
        }

        protected void ShowReportErrors(object sender, ReportErrorEventArgs e)
        {
            lblFeedback.Text = e.Exception.Message + e.Exception.StackTrace;

            if (e.Exception.InnerException != null)
            {
                lblFeedback.Text += e.Exception.InnerException.Message + e.Exception.InnerException.StackTrace;

                if (e.Exception.InnerException.InnerException != null)
                {
                    lblFeedback.Text += e.Exception.InnerException.InnerException.Message + e.Exception.InnerException.InnerException.StackTrace;
                }
            }
        }

        private List<ActiveCustomerDto> GetQueryResults(DateTime startDate, DateTime endDate, int programId)
        {
            return ActiveCustomersQueryFactory.CreateQuery(startDate, endDate, programId);
        }
    }
   
}